package com.example.umarsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
